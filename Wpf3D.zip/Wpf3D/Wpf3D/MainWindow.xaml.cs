﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf3D
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MouseLeftButtonDown += SceneMouseLeftButtonDown;
            MouseMove += SceneMouseMove;
            MouseLeftButtonUp += SceneMouseLeftButtonUp;
        }

        private void SceneMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            isMove = false;
        }

        bool isMove = false;
        private void SceneMouseMove(object sender, MouseEventArgs e)
        {
            if (!isMove) return;
            var current = e.GetPosition(Scene);
            MainCamera.Position = new Point3D((current.X - Point.Value.X) / 100 + MainCamera.Position.X, 
                MainCamera.Position.Y, MainCamera.Position.Z);
            Point = current;
        }

        Point? Point; 
        private void SceneMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
           var current = e.GetPosition(Scene);
            if (Point == null) { Point = current;  return; }
            isMove = true;
            Point = current;
        }
    }
}
